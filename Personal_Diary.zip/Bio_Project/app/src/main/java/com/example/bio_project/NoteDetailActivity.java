package com.example.bio_project;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Base64;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class NoteDetailActivity extends AppCompatActivity {

    private DatabaseReference databaseReference;
    private String noteId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note_detail);
        setTitle("Story Details");

        noteId = getIntent().getStringExtra("storyId");
        String serializedNote = getIntent().getStringExtra("story");
        final Note note = deserializeNoteObject(serializedNote);

        if (note != null) {
            TextView titleTextView = findViewById(R.id.titleTextView);
            TextView contentTextView = findViewById(R.id.contentTextView);
            titleTextView.setText(note.getTitle());
            contentTextView.setText(note.getContent());
        } else {
            Toast.makeText(this, "Error loading story details.", Toast.LENGTH_SHORT).show();
            finish();
        }

        Button deleteButton = findViewById(R.id.deleteButton);
        deleteButton.setOnClickListener(view -> deleteNote());

        databaseReference = FirebaseDatabase.getInstance().getReference("stories");
    }

    private void deleteNote() {
        if (noteId != null) {
            databaseReference.child(noteId).removeValue().addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    Toast.makeText(NoteDetailActivity.this, "Story deleted successfully", Toast.LENGTH_SHORT).show();
                    finish();  // Close the activity after deletion
                } else {
                    Toast.makeText(NoteDetailActivity.this, "Failed to delete the Story", Toast.LENGTH_SHORT).show();
                }
            });
        } else {
            Toast.makeText(this, "Error: Story ID is missing.", Toast.LENGTH_SHORT).show();
        }
    }

    private Note deserializeNoteObject(String serializedNote) {
        try {
            byte[] bytes = Base64.decode(serializedNote, Base64.DEFAULT);
            ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(bytes);
            ObjectInputStream objectInputStream = new ObjectInputStream(byteArrayInputStream);
            return (Note) objectInputStream.readObject();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            return null;
        }
    }
}
