package com.example.bio_project;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Date;

public class HomeActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private NoteAdapter noteAdapter;
    private ArrayList<Note> notes = new ArrayList<>();
    private DatabaseReference databaseNotes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        recyclerView = findViewById(R.id.rvNotes);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        noteAdapter = new NoteAdapter(this, notes);
        recyclerView.setAdapter(noteAdapter);

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser != null) {
            String userId = currentUser.getUid();
            databaseNotes = database.getReference("users").child(userId).child("Stories");
            loadNotesFromFirebase();
        } else {
            Log.e("HomeActivity", "Current user is null");
        }

        Button btnAddNote = findViewById(R.id.btnAddNote);
        btnAddNote.setOnClickListener(v -> openAddNoteDialog());

        ImageView imageViewSettings = findViewById(R.id.imageView2);
        imageViewSettings.setOnClickListener(v -> showSettingsDialog());
    }

    private void showSettingsDialog() {
        String[] themes = new String[]{"Light", "Dark", "System default"};
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Settings")
                .setItems(themes, (dialog, which) -> {
                    switch (themes[which]) {
                        case "Light":
                            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                            break;
                        case "Dark":
                            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                            break;
                        case "System default":
                            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM);
                            break;
                    }
                })
                .setPositiveButton("Logout", (dialog, which) -> {
                    FirebaseAuth.getInstance().signOut();
                    startActivity(new Intent(HomeActivity.this, MainActivity.class));
                    finish();
                })
                .setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss())
                .create().show();
    }

    private void loadNotesFromFirebase() {
        databaseNotes.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                notes.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    String noteId = snapshot.getKey(); // Retrieve the ID
                    Note note = snapshot.getValue(Note.class);
                    note.setId(noteId); // Set the ID for the note
                    notes.add(note);
                }
                noteAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.w("TAG", "loadStory:onCancelled", databaseError.toException());
            }
        });
    }

    private void openAddNoteDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View view = LayoutInflater.from(this).inflate(R.layout.dialog_add_note, null);
        final EditText editNoteTitle = view.findViewById(R.id.editNoteTitle);
        final EditText editNoteContent = view.findViewById(R.id.editNoteContent);

        builder.setView(view)
                .setTitle("Add your story")
                .setPositiveButton("Save", (dialog, which) -> {
                    String title = editNoteTitle.getText().toString().trim();
                    String content = editNoteContent.getText().toString().trim();
                    if (!title.isEmpty() && !content.isEmpty()) {
                        Note newNote = new Note(String.valueOf(System.currentTimeMillis()), title, content, new Date().getTime());
                        saveNoteToFirebase(newNote);
                    } else {
                        Toast.makeText(HomeActivity.this, "Story cant be stored without title and content", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss())
                .create().show();
    }

    private void saveNoteToFirebase(Note note) {
        String key = databaseNotes.push().getKey();
        if (key != null) {
            databaseNotes.child(key).setValue(note);
        }
    }
}
